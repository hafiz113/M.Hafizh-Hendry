import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(MyApp());

class Item {
  String title;
  String description;
  File? image;

  Item(this.title, this.description, this.image);
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  List<Item> items = [];

  final picker = ImagePicker();
  File? _image;

  final _titleController = TextEditingController();
  final _descController = TextEditingController();

  Future<void> pickImage() async {
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        _image = File(picked.path);
      });
    }
  }

  void postItem() {
    if (_titleController.text.isEmpty || _descController.text.isEmpty) return;

    setState(() {
      items.add(Item(_titleController.text, _descController.text, _image));
      _titleController.clear();
      _descController.clear();
      _image = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Marketplace Lokal',
      home: Scaffold(
        appBar: AppBar(title: Text("Marketplace Lokal")),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                TextField(
                  controller: _titleController,
                  decoration: InputDecoration(labelText: 'Judul Barang'),
                ),
                TextField(
                  controller: _descController,
                  decoration: InputDecoration(labelText: 'Deskripsi'),
                ),
                SizedBox(height: 10),
                _image != null
                    ? Image.file(_image!, height: 150)
                    : Text('Belum pilih gambar'),
                ElevatedButton(
                  onPressed: pickImage,
                  child: Text("Pilih Gambar"),
                ),
                SizedBox(height: 10),
                ElevatedButton(onPressed: postItem, child: Text("Post Barang")),
                Divider(),
                Text(
                  "Barang yang Diposting",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                ...items.map(
                  (item) => Card(
                    child: ListTile(
                      leading: item.image != null
                          ? Image.file(
                              item.image!,
                              width: 50,
                              height: 50,
                              fit: BoxFit.cover,
                            )
                          : null,
                      title: Text(item.title),
                      subtitle: Text(item.description),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
