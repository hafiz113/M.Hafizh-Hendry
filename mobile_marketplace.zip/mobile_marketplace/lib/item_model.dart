class Item {
  String title;
  String description;
  String imagePath;

  Item({
    required this.title,
    required this.description,
    required this.imagePath,
  });
}
