import 'dart:io';
import 'package:flutter/material.dart';
import 'item_model.dart';
import 'add_item_page.dart';
import 'edit_item_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Item> items = [];

  void addItem(Item newItem) {
    setState(() {
      items.add(newItem);
    });
  }

  void editItem(int index, Item updatedItem) {
    setState(() {
      items[index] = updatedItem;
    });
  }

  void deleteItem(int index) {
    setState(() {
      items.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Marketplace")),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          final item = items[index];
          return Card(
            margin: const EdgeInsets.all(8),
            child: ListTile(
              leading: Image.file(
                File(item.imagePath),
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
              title: Text(item.title),
              subtitle: Text(item.description),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  PopupMenuButton<String>(
                    onSelected: (value) {
                      if (value == 'edit') {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => EditItemPage(
                              item: item,
                              onSave: (updatedItem) =>
                                  editItem(index, updatedItem),
                            ),
                          ),
                        );
                      } else if (value == 'delete') {
                        deleteItem(index);
                      }
                    },
                    itemBuilder: (context) => [
                      const PopupMenuItem(
                        value: 'edit',
                        child: Text('✏️ Edit'),
                      ),
                      const PopupMenuItem(
                        value: 'delete',
                        child: Text('🗑️ Hapus'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newItem = await Navigator.push<Item>(
            context,
            MaterialPageRoute(builder: (_) => const AddItemPage()),
          );
          if (newItem != null) {
            addItem(newItem);
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
